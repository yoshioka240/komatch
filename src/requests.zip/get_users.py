import requests
import json
import boto3

url = 'https://slack.com/api/users.list'
token = 'xoxb-1269020941138-1275956616086-by0xpVS1BQvINqiTCGHlWqyI'

# ユーザー情報を取得
payload = {'token': token}
response = requests.get(url,params=payload)
members_info = response.json()['members']

# DynamoDBに登録
table_name = 'DevKomatch'
dynamo = boto3.client('dynamodb')
for _ in range(len(members_info)):
    item1 = {
        'id': {'S': members_info[_]['id'].encode('utf-8')},
        'data_type': {'S': 'Name'},
        'data_value': {'S': members_info[_]['name'].encode('utf-8')}
    }
    item2 = {
        'id': {'S': members_info[_]['id'].encode('utf-8')},
        'data_type': {'S': 'WorkspaceID'},
        'data_value': {'S': members_info[_]['name'].encode('utf-8')}
    }
    dynamo.put_item(TableName=table_name, Item=item1)
    dynamo.put_item(TableName=table_name, Item=item2)
